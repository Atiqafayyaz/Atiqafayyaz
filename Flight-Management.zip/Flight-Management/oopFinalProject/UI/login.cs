﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using oopFinalProject.DL;
using oopFinalProject.UI;

namespace oopFinalProject
{
    public partial class login : Form
    {
        AccountBL accountBL;
        AccountDL accountDL = new AccountDL();
        public login()
        {
            InitializeComponent();
            this.DoubleBuffered = true;  // Smooth rendering
            this.SetStyle(ControlStyles.AllPaintingInWmPaint |
                          ControlStyles.UserPaint |
                          ControlStyles.OptimizedDoubleBuffer, true);
            this.UpdateStyles();

        }

        private void guna2HtmlLabel3_Click(object sender, EventArgs e)
        {
            forgotpassword fp = new forgotpassword();
            this.Hide();
            fp.Show();
        }

        private void guna2HtmlLabel2_Click(object sender, EventArgs e)
        {
            createaccount ca = new createaccount();
            this.Hide();
            ca.Show();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            string email = guna2TextBox1.Text;
            string password = Password.Text;
            int userID = accountDL.getuserid(email);

            accountBL = new AccountBL(email, password);
            int result = accountBL.Signin();
            if (result == 0)
            {
                MessageBox.Show("Invalid inputs");
            }
            else if (result == 1)
            {
                admindashboard ad = new admindashboard();
                this.Hide();
                ad.Show();
            }
            else
            {
                customerdashboard cu = new customerdashboard(userID);
                this.Hide();
                cu.Show();

            }
        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
