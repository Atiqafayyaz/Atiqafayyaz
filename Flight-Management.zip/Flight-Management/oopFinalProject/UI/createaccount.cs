﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Guna.UI2.WinForms;

namespace oopFinalProject.UI
{
    public partial class createaccount : Form
    {
        AccountBL accountbl;
        public createaccount()
        {
            InitializeComponent();
            this.DoubleBuffered = true;  // Smooth rendering
            this.SetStyle(ControlStyles.AllPaintingInWmPaint |
                          ControlStyles.UserPaint |
                          ControlStyles.OptimizedDoubleBuffer, true);
            this.UpdateStyles();
        }

        private void newpassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            string username = usernam.Text;
            string email = Email.Text;
            string password = Password.Text;
            string result;

            accountbl = new AccountBL(username, email, password);
            result = accountbl.AddAccount();
            MessageBox.Show(result);
            if (result == "Acount Created Successfully")
            {
                ClearTextFields();
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            login lo = new login();
            this.Hide();
            lo.Show();
        }
        private void ClearTextFields()
        {
            usernam.Text = "";
            Email.Text = "";
            Password.Text = "";

        }
    }
}
