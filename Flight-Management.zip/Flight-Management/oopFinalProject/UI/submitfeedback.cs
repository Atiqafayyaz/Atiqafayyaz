﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic.ApplicationServices;
using oopFinalProject.BL;

namespace oopFinalProject.UI
{
    public partial class submitfeedback : Form
    {
        FeedbackBL feedbackbl;
        private int UserID;
        public submitfeedback(int userid)
        {
            InitializeComponent();
            this.DoubleBuffered = true;  // Smooth rendering
            this.SetStyle(ControlStyles.AllPaintingInWmPaint |
                          ControlStyles.UserPaint |
                          ControlStyles.OptimizedDoubleBuffer, true);
            this.UpdateStyles();
            UserID = userid;
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            string feedback = textBox1.Text;
            feedbackbl = new FeedbackBL(feedback);

            MessageBox.Show(feedbackbl.SubmitFeedback(UserID));
        }

        private void submitfeedback_Load(object sender, EventArgs e)
        {

        }
    }
}
