﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using Guna.UI2.WinForms;
using oopFinalProject.BL;
using oopFinalProject.DL;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace oopFinalProject.UI
{
    public partial class AddStaff : Form
    {
        staffDL staffDL = new staffDL();
        staffBL staffBL;
        private int staffId;
        public AddStaff()
        {
            InitializeComponent();
            this.DoubleBuffered = true;  // Smooth rendering
            this.SetStyle(ControlStyles.AllPaintingInWmPaint |
                          ControlStyles.UserPaint |
                          ControlStyles.OptimizedDoubleBuffer, true);
            this.UpdateStyles();
            LoaddesignationData();
            LoadairportData();
            staffId = 0;
        }
        public AddStaff(int staffid, string name, string address, string contact, int airportId,  int designationId,  string date)
        {

            InitializeComponent();
            this.DoubleBuffered = true;  // Smooth rendering
            this.SetStyle(ControlStyles.AllPaintingInWmPaint |
                          ControlStyles.UserPaint |
                          ControlStyles.OptimizedDoubleBuffer, true);
            this.UpdateStyles();
            LoaddesignationData();
            LoadairportData();
            FillDetails(staffid, name, address, contact, airportId, designationId, date);
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (guna2ComboBox2.SelectedValue == null || guna2ComboBox3.SelectedValue == null)
            {
                MessageBox.Show("Please select all information.");
                return;
            }
            string name = guna2TextBox1.Text;
            string contact = guna2TextBox2.Text;
            string address = guna2TextBox3.Text;
            int designation = Convert.ToInt32(guna2ComboBox2.SelectedValue);
            int airport = Convert.ToInt32(guna2ComboBox3.SelectedValue);
            string date = dateTimePicker1.Text;
            staffBL = new staffBL(name , contact , address , designation , airport , date);
            string result;
            if (staffId > 0)
            {
                result = staffBL.UpdateStaff(staffId);
                MessageBox.Show(result);
                if (result == "Staff Updated Successfully")
                {
                    ClearTextFields();
                }
            }
            else
            {

                result = staffBL.AddStaff();
                MessageBox.Show(result);
                if (result == "Staff Added Successfully")
                {
                    ClearTextFields();
                }
            }

        }
        private void LoaddesignationData()
        {
            DataTable dt = staffDL.Getdesignation();
            guna2ComboBox2.DataSource = dt;
            guna2ComboBox2.DisplayMember = "value";
            guna2ComboBox2.ValueMember = "lookup_id";
            guna2ComboBox2.SelectedIndex = -1;

        }
        private void LoadairportData()
        {
            DataTable dt = staffDL.Getairport();
            guna2ComboBox3.DataSource = dt;
            guna2ComboBox3.DisplayMember = "value";
            guna2ComboBox3.ValueMember = "lookup_id";
            guna2ComboBox3.SelectedIndex = -1;

        }
        public void FillDetails(int staffid, string name, string address, string contact, int airportId, int designationId, string date)
        {

            this.staffId = staffid;
            guna2TextBox1.Text = name;
            guna2TextBox2.Text = contact;
            guna2TextBox3.Text = address;
            guna2ComboBox2.SelectedValue = designationId;
            guna2ComboBox3.SelectedValue = airportId;
            dateTimePicker1.Text = date;


        }
        private void ClearTextFields()
        {
            guna2TextBox1.Text = "";
            guna2TextBox2.Text = "";
            guna2TextBox3.Text = "";
            
            guna2ComboBox2.ResetText();
            guna2ComboBox2.SelectedIndex = -1;

            guna2ComboBox3.ResetText();
            guna2ComboBox3.SelectedIndex = -1;

        }
    }
}
