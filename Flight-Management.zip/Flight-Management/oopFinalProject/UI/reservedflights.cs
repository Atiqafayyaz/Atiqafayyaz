﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using oopFinalProject.BL;
using oopFinalProject.DL;

namespace oopFinalProject.UI
{
    public partial class reservedflights : Form
    {
      
        BookingDL bookingdl = new BookingDL();
        BookingBL bookingbl;
        private int UserId = 0;
        
        public reservedflights(int userid)
        {
            InitializeComponent();
            this.DoubleBuffered = true;  // Smooth rendering avoid flickering
            this.SetStyle(ControlStyles.AllPaintingInWmPaint |
                          ControlStyles.UserPaint |
                          ControlStyles.OptimizedDoubleBuffer, true);
            this.UpdateStyles(); //ensure setting will apply
            UserId = userid;
            bookingbl = new BookingBL(UserId);
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(bookingbl.GetNotified());
            string cnic = guna2TextBox1.Text;
            if (string.IsNullOrWhiteSpace(cnic)) 
            {
                MessageBox.Show("Please Enter your CNIC");
                return;
            }
            if (!Regex.IsMatch(cnic, @"^\d+$") || cnic.StartsWith(" "))
            {
                MessageBox.Show("Invalid Input");
                return;
            }
            LoadData(cnic);
        }

        private void LoadData(string cnic)
        {

            DataTable bookingData = bookingdl.GetReservedFlightData(cnic);
            if (bookingData != null)
            {

                dataGridView1.DataSource = bookingData;
                if (dataGridView1.Columns["booking_id"] != null)
                {
                    dataGridView1.Columns["booking_id"].Visible = false;
                }
            }
            else
            {
                MessageBox.Show("No data available.");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
