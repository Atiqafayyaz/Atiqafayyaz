﻿namespace oopFinalProject.UI
{
    partial class dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            adminpanel = new Panel();
            label7 = new Label();
            panel1 = new Panel();
            label5 = new Label();
            label4 = new Label();
            label6 = new Label();
            adminpanel.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // adminpanel
            // 
            adminpanel.BackgroundImageLayout = ImageLayout.Stretch;
            adminpanel.Controls.Add(label7);
            adminpanel.Controls.Add(panel1);
            adminpanel.Location = new Point(-2, -1);
            adminpanel.Name = "adminpanel";
            adminpanel.Size = new Size(1123, 723);
            adminpanel.TabIndex = 2;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Indigo;
            label7.Font = new Font("Algerian", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.ControlLightLight;
            label7.Location = new Point(294, 196);
            label7.Name = "label7";
            label7.Size = new Size(495, 54);
            label7.TabIndex = 1;
            label7.Text = "NextWing Airlines";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Indigo;
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label6);
            panel1.Location = new Point(0, 3);
            panel1.Name = "panel1";
            panel1.Size = new Size(1135, 96);
            panel1.TabIndex = 0;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = SystemColors.ControlLightLight;
            label5.Location = new Point(181, 18);
            label5.Name = "label5";
            label5.Size = new Size(44, 32);
            label5.TabIndex = 1;
            label5.Text = "___";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.ControlLightLight;
            label4.Location = new Point(29, 29);
            label4.Name = "label4";
            label4.Size = new Size(159, 38);
            label4.TabIndex = 1;
            label4.Text = "Dashboard";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = SystemColors.ControlLightLight;
            label6.Location = new Point(181, 29);
            label6.Name = "label6";
            label6.Size = new Size(44, 32);
            label6.TabIndex = 2;
            label6.Text = "___";
            // 
            // dashboard
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1116, 719);
            Controls.Add(adminpanel);
            Name = "dashboard";
            Text = "dashboard";
            adminpanel.ResumeLayout(false);
            adminpanel.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel adminpanel;
        private Label label7;
        private Panel panel1;
        private Label label5;
        private Label label4;
        private Label label6;
    }
}