﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataLayer;
using Guna.UI2.WinForms;
using oopFinalProject.BL;
using oopFinalProject.DL;

namespace oopFinalProject.UI
{
    public partial class bookflight : Form
    {
        BookingDL booking = new BookingDL();
        BookingBL bookingbl;
        private int UserID = 0;
        public bookflight(int userID)
        {
            InitializeComponent();
            this.DoubleBuffered = true;  // Smooth rendering avoid flickering
            this.SetStyle(ControlStyles.AllPaintingInWmPaint |
                          ControlStyles.UserPaint |
                          ControlStyles.OptimizedDoubleBuffer, true);
            this.UpdateStyles(); //ensure setting will apply

            DepartureairportData();
            ArrivalairportData();
            LoadData();
            UserID = userID;
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void guna2ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
        private void guna2ComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1 )
            {
               
                var selectedRow = dataGridView1.SelectedRows[0];

                int flightId = Convert.ToInt32(selectedRow.Cells["flight_id"].Value.ToString());
                string number = selectedRow.Cells["flight_number"].Value.ToString();

                guna2TextBox1.Text = flightId.ToString();
                guna2TextBox2.Text = number;

            }
          
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(guna2TextBox1.Text))
            {
                MessageBox.Show("Please Enter All Information");
                return;
            }
            int flightId = Convert.ToInt32(guna2TextBox1.Text);
            string name = guna2TextBox3.Text;
            string cnic = guna2TextBox4.Text;
            string result;

            bookingbl = new BookingBL(flightId, name, cnic, UserID);
            result = bookingbl.Bookflight();
            MessageBox.Show(result);
            if (result == "Your Flight Booked Successfully") ;
            {
                ClearTextFields();
            }

        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            int departureId = 0;
            int arrivalId = 0;

            DataRowView departureselectedRow = (DataRowView)guna2ComboBox1.SelectedItem;
            DataRowView arrivalselectedRow = (DataRowView)guna2ComboBox2.SelectedItem;
            if (departureselectedRow != null)
            {
                departureId = Convert.ToInt32(departureselectedRow["lookup_id"]);
            }

            if (arrivalselectedRow != null)
            {
                arrivalId = Convert.ToInt32(arrivalselectedRow["lookup_id"]);
            }
            LoadFilteredData(departureId, arrivalId);
        }
        private void LoadData()
        {

            DataTable flightdata = booking.GetflightData();
            if (flightdata != null)
            {

                dataGridView1.DataSource = flightdata;

            }
            else
            {
                MessageBox.Show("No data available.");
            }
        }
        private void LoadFilteredData(int departureID, int arrivalID)
        {
            DataTable bookingData = booking.LoadFilteredData(departureID, arrivalID);
            if (bookingData != null)
            {

                dataGridView1.DataSource = bookingData;
            }
            else
            {
                MessageBox.Show("No data available.");
            }

        }

        private void DepartureairportData()
        {
            DataTable dt = booking.Getairport();
            guna2ComboBox1.DataSource = dt;
            guna2ComboBox1.DisplayMember = "value";
            guna2ComboBox1.ValueMember = "lookup_id";
            guna2ComboBox1.SelectedIndex = -1;

        }
        private void ArrivalairportData()
        {
            DataTable dt = booking.Getairport();
            guna2ComboBox2.DataSource = dt;
            guna2ComboBox2.DisplayMember = "value";
            guna2ComboBox2.ValueMember = "lookup_id";
            guna2ComboBox2.SelectedIndex = -1;

        }
        private void ClearTextFields()
        {
            guna2TextBox1.Text = "";
            guna2TextBox4.Text = "";
            guna2TextBox2.Text = "";
            guna2TextBox3.Text = "";

            guna2ComboBox2.ResetText();
            guna2ComboBox2.SelectedIndex = -1;

            guna2ComboBox1.ResetText();
            guna2ComboBox1.SelectedIndex = -1;


        }

        private void guna2ComboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }
    }
}
