﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using oopFinalProject.BL;
using oopFinalProject.DL;

namespace oopFinalProject.UI
{
    public partial class viewflight : Form
    {
        FlightDL flightdl = new FlightDL();

        public viewflight()
        {
            InitializeComponent();
            this.DoubleBuffered = true;  // Smooth rendering avoid flickering
            this.SetStyle(ControlStyles.AllPaintingInWmPaint |
                          ControlStyles.UserPaint |
                          ControlStyles.OptimizedDoubleBuffer, true);
            this.UpdateStyles(); //ensure setting will apply
            LoadData();
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                var selectedRow = dataGridView1.SelectedRows[0];

                int flightid = Convert.ToInt32(selectedRow.Cells["flight_id"].Value);
                string number = selectedRow.Cells["flight_number"].Value.ToString();
                int typeid = Convert.ToInt32(selectedRow.Cells["type_id"].Value);
                int seats = Convert.ToInt32(selectedRow.Cells["total_seats"].Value);
                float price = float.Parse(selectedRow.Cells["price"].Value.ToString());
                float discount = float.Parse(selectedRow.Cells["discount_percentage"].Value.ToString());
                int departureairportId = Convert.ToInt32(selectedRow.Cells["departure_airport_id"].Value);
                int arrivalairportId = Convert.ToInt32(selectedRow.Cells["arrival_airport_id"].Value);
                DateTime departureTime = Convert.ToDateTime(selectedRow.Cells["departure_time"].Value);
                DateTime arrivalTime = Convert.ToDateTime(selectedRow.Cells["arrival_time"].Value);


                addflight edit = new addflight();
                edit.FillDetails(flightid, number, typeid, seats, price, discount, departureairportId, arrivalairportId, departureTime, arrivalTime);
                admindashboard admin = (admindashboard)this.ParentForm;
                admin.OpenFormInPanel(edit);
            }
            else
            {
                MessageBox.Show("Please Select one Row");
            }
        }


        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {
            string search = guna2TextBox1.Text;
            DataTable searchData = flightdl.GetSearchData(search);
            if (searchData != null)
            {
                dataGridView1.DataSource = searchData;
            }
        }        
        private void guna2Button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                var selectedRow = dataGridView1.SelectedRows[0];
                int flightid = Convert.ToInt32(selectedRow.Cells["flight_id"].Value);
                bool isDeleted = flightdl.DeleteFlight(flightid);
                if (isDeleted)
                {
                    MessageBox.Show("flight Deleted Seccessfully");
                }
                else
                {
                    MessageBox.Show("Please try Again");
                }

            }
            else
            {
                MessageBox.Show("Please Select one Row");
            }
            LoadData();
        }

        private void LoadData()
        {

            DataTable staffData = flightdl.GetData();
            if (staffData != null)
            {

                dataGridView1.DataSource = staffData;
                if (dataGridView1.Columns["flight_id"] != null)
                {
                    dataGridView1.Columns["flight_id"].Visible = false;
                }
                if (dataGridView1.Columns["type_id"] != null)
                {
                    dataGridView1.Columns["type_id"].Visible = false;
                }
                if (dataGridView1.Columns["departure_airport_id"] != null)
                {
                    dataGridView1.Columns["departure_airport_id"].Visible = false;
                }
                if (dataGridView1.Columns["arrival_airport_id"] != null)
                {
                    dataGridView1.Columns["arrival_airport_id"].Visible = false;
                }
            }
            else
            {
                MessageBox.Show("No data available.");
            }
        }

    }
}
