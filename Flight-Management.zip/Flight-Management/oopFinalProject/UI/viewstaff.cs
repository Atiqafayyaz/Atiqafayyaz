﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using oopFinalProject.BL;
using oopFinalProject.DL;

namespace oopFinalProject.UI
{
    public partial class viewstaff : Form
    {
        staffDL staffdl = new staffDL();
        public viewstaff()
        {
            
            InitializeComponent();
            this.DoubleBuffered = true;  // Smooth rendering avoid flickering
            this.SetStyle(ControlStyles.AllPaintingInWmPaint |
                          ControlStyles.UserPaint |
                          ControlStyles.OptimizedDoubleBuffer, true);
            this.UpdateStyles(); //ensure setting will apply
            LoadData();
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {
            string search = guna2TextBox1.Text;
            DataTable searchData = staffdl.GetSearchData(search);
            if (searchData != null)
            {
                dataGridView1.DataSource = searchData;
            }

        }
       
        private void guna2Button1_Click(object sender, EventArgs e)
        {
            
            if (dataGridView1.SelectedRows.Count == 1)
            {
                var selectedRow = dataGridView1.SelectedRows[0];

                int staffid = Convert.ToInt32(selectedRow.Cells["staff_id"].Value);
                string name = selectedRow.Cells["name"].Value.ToString();
                string address = selectedRow.Cells["address"].Value.ToString();
                string contact = selectedRow.Cells["contact"].Value.ToString();
                int airportId = Convert.ToInt32(selectedRow.Cells["airport_id"].Value);
                int designationId = Convert.ToInt32(selectedRow.Cells["designation_id"].Value);
                string date = selectedRow.Cells["date_of_joining"].Value.ToString();


                AddStaff edit = new AddStaff();
                edit.FillDetails(staffid , name , address , contact , airportId , designationId , date);
                admindashboard admin = (admindashboard)this.ParentForm;
                admin.OpenFormInPanel(edit);
            }
            else
            {
                MessageBox.Show("Please Select one row First");
            }


        }

        private void LoadData()
        {

            DataTable staffData = staffdl.GetEntireData();
            if (staffData != null)
            {

                dataGridView1.DataSource = staffData;
                if (dataGridView1.Columns["staff_id"] != null)
                {
                    dataGridView1.Columns["staff_id"].Visible = false;
                }
                if (dataGridView1.Columns["airport_id"] != null)
                {
                    dataGridView1.Columns["airport_id"].Visible = false;
                }
                if (dataGridView1.Columns["designation_id"] != null)
                {
                    dataGridView1.Columns["designation_id"].Visible = false;
                }
            }
            else
            {
                MessageBox.Show("No data available.");
            }
        }

        public void OpenFormInPanel(Form form)
        {
            Controls.Clear(); // Remove previous form
            form.TopLevel = false;  // Set as child control
            form.FormBorderStyle = FormBorderStyle.None;  // Remove window border
            form.Dock = DockStyle.Fill;  // Make it fill the panel
            Controls.Add(form);  // Add to panel
            form.Show();
        }
    }
}
