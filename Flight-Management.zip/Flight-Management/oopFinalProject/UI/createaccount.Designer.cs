﻿namespace oopFinalProject.UI
{
    partial class createaccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(createaccount));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            Password = new Guna.UI2.WinForms.Guna2TextBox();
            Email = new Guna.UI2.WinForms.Guna2TextBox();
            guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            usernam = new Guna.UI2.WinForms.Guna2TextBox();
            guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox1).BeginInit();
            SuspendLayout();
            // 
            // guna2Panel1
            // 
            guna2Panel1.BackColor = Color.AliceBlue;
            guna2Panel1.BackgroundImage = Properties.Resources.istockphoto_1435244230_612x612;
            guna2Panel1.BackgroundImageLayout = ImageLayout.Stretch;
            guna2Panel1.BorderRadius = 100;
            guna2Panel1.Controls.Add(label4);
            guna2Panel1.Controls.Add(label3);
            guna2Panel1.Controls.Add(label2);
            guna2Panel1.Controls.Add(label1);
            guna2Panel1.Controls.Add(guna2PictureBox3);
            guna2Panel1.Controls.Add(Password);
            guna2Panel1.Controls.Add(Email);
            guna2Panel1.Controls.Add(guna2Button1);
            guna2Panel1.Controls.Add(guna2PictureBox2);
            guna2Panel1.Controls.Add(guna2PictureBox1);
            guna2Panel1.Controls.Add(guna2HtmlLabel1);
            guna2Panel1.Controls.Add(usernam);
            guna2Panel1.CustomizableEdges = customizableEdges15;
            guna2Panel1.Location = new Point(177, 105);
            guna2Panel1.Name = "guna2Panel1";
            guna2Panel1.ShadowDecoration.CustomizableEdges = customizableEdges16;
            guna2Panel1.Size = new Size(496, 612);
            guna2Panel1.TabIndex = 2;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI Black", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.ButtonHighlight;
            label4.Location = new Point(96, 571);
            label4.Name = "label4";
            label4.Size = new Size(54, 25);
            label4.TabIndex = 14;
            label4.Text = "Back";
            label4.Click += label4_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.ForeColor = SystemColors.Control;
            label3.Location = new Point(131, 386);
            label3.Name = "label3";
            label3.Size = new Size(91, 25);
            label3.TabIndex = 12;
            label3.Text = "Password:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.ForeColor = SystemColors.Control;
            label2.Location = new Point(131, 284);
            label2.Name = "label2";
            label2.Size = new Size(58, 25);
            label2.TabIndex = 11;
            label2.Text = "Email:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.ForeColor = SystemColors.Control;
            label1.Location = new Point(131, 176);
            label1.Name = "label1";
            label1.Size = new Size(93, 25);
            label1.TabIndex = 10;
            label1.Text = "username:";
            // 
            // guna2PictureBox3
            // 
            guna2PictureBox3.CustomizableEdges = customizableEdges1;
            guna2PictureBox3.Image = (Image)resources.GetObject("guna2PictureBox3.Image");
            guna2PictureBox3.ImageRotate = 0F;
            guna2PictureBox3.Location = new Point(54, 414);
            guna2PictureBox3.Name = "guna2PictureBox3";
            guna2PictureBox3.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2PictureBox3.Size = new Size(42, 42);
            guna2PictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            guna2PictureBox3.TabIndex = 9;
            guna2PictureBox3.TabStop = false;
            // 
            // Password
            // 
            Password.BackColor = Color.Transparent;
            Password.BorderRadius = 20;
            Password.CustomizableEdges = customizableEdges3;
            Password.DefaultText = "";
            Password.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            Password.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            Password.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            Password.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            Password.FillColor = Color.Snow;
            Password.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            Password.Font = new Font("Segoe UI", 9F);
            Password.ForeColor = Color.Black;
            Password.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            Password.Location = new Point(116, 416);
            Password.Margin = new Padding(4, 5, 4, 5);
            Password.Name = "Password";
            Password.PlaceholderForeColor = Color.DarkGray;
            Password.PlaceholderText = "password";
            Password.SelectedText = "";
            Password.ShadowDecoration.CustomizableEdges = customizableEdges4;
            Password.Size = new Size(314, 40);
            Password.TabIndex = 8;
            Password.UseSystemPasswordChar = true;
            Password.TextChanged += newpassword_TextChanged;
            // 
            // Email
            // 
            Email.BackColor = Color.Transparent;
            Email.BorderRadius = 20;
            Email.CustomizableEdges = customizableEdges5;
            Email.DefaultText = "";
            Email.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            Email.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            Email.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            Email.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            Email.FillColor = Color.Snow;
            Email.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            Email.Font = new Font("Segoe UI", 9F);
            Email.ForeColor = Color.Black;
            Email.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            Email.Location = new Point(116, 314);
            Email.Margin = new Padding(4, 5, 4, 5);
            Email.Name = "Email";
            Email.PlaceholderForeColor = Color.DarkGray;
            Email.PlaceholderText = "email";
            Email.SelectedText = "";
            Email.ShadowDecoration.CustomizableEdges = customizableEdges6;
            Email.Size = new Size(314, 40);
            Email.TabIndex = 7;
            // 
            // guna2Button1
            // 
            guna2Button1.BackColor = Color.White;
            guna2Button1.BorderRadius = 25;
            guna2Button1.CustomizableEdges = customizableEdges7;
            guna2Button1.DisabledState.BorderColor = Color.DarkGray;
            guna2Button1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button1.FillColor = Color.MidnightBlue;
            guna2Button1.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2Button1.ForeColor = Color.White;
            guna2Button1.Location = new Point(96, 507);
            guna2Button1.Name = "guna2Button1";
            guna2Button1.ShadowDecoration.CustomizableEdges = customizableEdges8;
            guna2Button1.Size = new Size(317, 47);
            guna2Button1.TabIndex = 1;
            guna2Button1.Text = "create";
            guna2Button1.Click += guna2Button1_Click;
            // 
            // guna2PictureBox2
            // 
            guna2PictureBox2.CustomizableEdges = customizableEdges9;
            guna2PictureBox2.ErrorImage = null;
            guna2PictureBox2.Image = (Image)resources.GetObject("guna2PictureBox2.Image");
            guna2PictureBox2.ImageRotate = 0F;
            guna2PictureBox2.Location = new Point(54, 312);
            guna2PictureBox2.Name = "guna2PictureBox2";
            guna2PictureBox2.ShadowDecoration.CustomizableEdges = customizableEdges10;
            guna2PictureBox2.Size = new Size(42, 42);
            guna2PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            guna2PictureBox2.TabIndex = 3;
            guna2PictureBox2.TabStop = false;
            // 
            // guna2PictureBox1
            // 
            guna2PictureBox1.CustomizableEdges = customizableEdges11;
            guna2PictureBox1.Image = Properties.Resources.images;
            guna2PictureBox1.ImageRotate = 0F;
            guna2PictureBox1.Location = new Point(54, 204);
            guna2PictureBox1.Name = "guna2PictureBox1";
            guna2PictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges12;
            guna2PictureBox1.Size = new Size(42, 42);
            guna2PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            guna2PictureBox1.TabIndex = 1;
            guna2PictureBox1.TabStop = false;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Transparent;
            guna2HtmlLabel1.Font = new Font("Algerian", 22F, FontStyle.Regular, GraphicsUnit.Point, 0);
            guna2HtmlLabel1.ForeColor = SystemColors.ButtonHighlight;
            guna2HtmlLabel1.Location = new Point(72, 65);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(370, 51);
            guna2HtmlLabel1.TabIndex = 0;
            guna2HtmlLabel1.Text = "Create Account";
            // 
            // usernam
            // 
            usernam.BackColor = Color.Transparent;
            usernam.BorderRadius = 20;
            usernam.CustomizableEdges = customizableEdges13;
            usernam.DefaultText = "";
            usernam.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            usernam.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            usernam.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            usernam.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            usernam.FillColor = Color.Snow;
            usernam.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            usernam.Font = new Font("Segoe UI", 9F);
            usernam.ForeColor = Color.Black;
            usernam.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            usernam.Location = new Point(116, 206);
            usernam.Margin = new Padding(4, 5, 4, 5);
            usernam.Name = "usernam";
            usernam.PlaceholderForeColor = Color.DarkGray;
            usernam.PlaceholderText = "username";
            usernam.SelectedText = "";
            usernam.ShadowDecoration.CustomizableEdges = customizableEdges14;
            usernam.Size = new Size(314, 40);
            usernam.TabIndex = 6;
            // 
            // createaccount
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1477, 777);
            Controls.Add(guna2Panel1);
            Name = "createaccount";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "createaccount";
            guna2Panel1.ResumeLayout(false);
            guna2Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Label label3;
        private Label label2;
        private Label label1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private Guna.UI2.WinForms.Guna2TextBox Password;
        private Guna.UI2.WinForms.Guna2TextBox Email;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2TextBox usernam;
        private Label label4;
    }
}