﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using oopFinalProject.BL;
using oopFinalProject.DL;

namespace oopFinalProject.UI
{
    public partial class viewfeedback : Form
    {
        FeedbackDL feedback = new FeedbackDL();
        public viewfeedback()
        {
            InitializeComponent();
            this.DoubleBuffered = true;  // Smooth rendering avoid flickering
            this.SetStyle(ControlStyles.AllPaintingInWmPaint |
                          ControlStyles.UserPaint |
                          ControlStyles.OptimizedDoubleBuffer, true);
            this.UpdateStyles(); //ensure setting will apply
            LoadData();
        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {
            string search = guna2TextBox1.Text;
            DataTable searchData = feedback.GetSearchData(search);
            if (searchData != null)
            {
                dataGridView1.DataSource = searchData;
            }


        }
        private void LoadData()
        {

            DataTable bookingData = feedback.GetData();
            if (bookingData != null)
            {

                dataGridView1.DataSource = bookingData;
            }
            else
            {
                MessageBox.Show("No data available.");
            }
        }
    }
}
