﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Guna.UI2.WinForms;
using oopFinalProject.BL;
using oopFinalProject.DL;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace oopFinalProject.UI
{
    public partial class addflight : Form
    {

        Domesticflight domesticflight;
        Internationalflight internationalflight;
        FlightDL flightdl = new FlightDL();
        private int flight_ID;
        public addflight()
        {
            InitializeComponent();
            this.DoubleBuffered = true;  // Smooth rendering
            this.SetStyle(ControlStyles.AllPaintingInWmPaint |
                          ControlStyles.UserPaint |
                          ControlStyles.OptimizedDoubleBuffer, true);
            this.UpdateStyles();
            LoadFlightType();
            flight_ID = 0;
        }
        public addflight(int flightid, string number, int typeid, int seats, float price, float discount, int departureairportId, int arrivalairportId, DateTime departureTime, DateTime arrivalTime)
        {
            InitializeComponent();
            this.DoubleBuffered = true;  // Smooth rendering
            this.SetStyle(ControlStyles.AllPaintingInWmPaint |
                          ControlStyles.UserPaint |
                          ControlStyles.OptimizedDoubleBuffer, true);
            this.UpdateStyles();
            LoadFlightType();
            FillDetails(flightid, number, typeid, seats, price, discount, departureairportId, arrivalairportId, departureTime, arrivalTime);


        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (
                string.IsNullOrWhiteSpace(guna2TextBox2.Text) || // validation for text box not null
                string.IsNullOrWhiteSpace(guna2TextBox5.Text) ||
                string.IsNullOrWhiteSpace(guna2TextBox4.Text))
            {
                MessageBox.Show("Please enter all information.");
                return;
            }
            if (guna2ComboBox2.SelectedValue == null || guna2ComboBox1.SelectedValue == null || guna2ComboBox3.SelectedValue == null)
            {
                MessageBox.Show("Please select all information."); //for combobox should not be null
                return;
            }
            string number = guna2TextBox1.Text;
            int seats;
            if (!int.TryParse(guna2TextBox2.Text, out seats))
            {
                MessageBox.Show("Please enter a valid number of seats.");
                guna2TextBox2.Focus();
                return;
            }

            // Validate price
            float price;
            if (!float.TryParse(guna2TextBox5.Text, out price))
            {
                MessageBox.Show("Please enter a valid price.");
                guna2TextBox5.Focus();
                return;
            }

            // Validate discount
            float discount;
            if (!float.TryParse(guna2TextBox4.Text, out discount))
            {
                MessageBox.Show("Please enter a valid discount.");
                guna2TextBox4.Focus();
                return;
            }

            int typeID = Convert.ToInt32(guna2ComboBox3.SelectedValue);
            int departureID = Convert.ToInt32(guna2ComboBox2.SelectedValue);
            int arrivalID = Convert.ToInt32(guna2ComboBox1.SelectedValue);
            DateTime departureTime = dateTimePicker2.Value;
            DateTime arrivalTime = dateTimePicker1.Value;
            string result;
            if (typeID == 16)
            {
                internationalflight = new Internationalflight(number, seats, price, discount, departureID, arrivalID, typeID, departureTime, arrivalTime);
                if (flight_ID > 0)
                {
                    result = internationalflight.UpdateFlight(flight_ID);
                    MessageBox.Show(result);
                    if (result == "Flight Updated Successfully")
                    {
                        ClearTextFields();
                    }
                }
                else
                {
                    result = internationalflight.AddFlight();
                    MessageBox.Show(result);
                    if (result == "Flight Added Successfully")
                    {
                        ClearTextFields();
                    }
                }
            }
            else if (typeID == 17)
            {
                domesticflight = new Domesticflight(number, seats, price, discount, departureID, arrivalID, typeID, departureTime, arrivalTime);
                if (flight_ID > 0)
                {
                    result = domesticflight.UpdateFlight(flight_ID);
                    MessageBox.Show(result);
                    if (result == "Flight Updated Successfully")
                    {
                        ClearTextFields();
                    }
                }
                else
                {
                    result = domesticflight.AddFlight();
                    MessageBox.Show(result);
                    if (result == "Flight Added Successfully")
                    {
                        ClearTextFields();
                    }
                }
            }

        }
        
        private void guna2ComboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (guna2ComboBox3.SelectedItem == null) return;
            DataRowView selectedRow = (DataRowView)guna2ComboBox3.SelectedItem;

            // Extract the value from the row 
            int typeID = Convert.ToInt32(selectedRow["lookup_id"]); //fill departure and arrival combobox according to flight type
            if (typeID == 16)
            {
                LoadInternationalDepartureData();
                LoadInternationalArrivalData1();
            }
            else if (typeID == 17)
            {
                LoadDomesticDepartureData();
                LoadDomesticArrivalData1();

            }

        }
        public void FillDetails(int flightid, string number, int typeid, int seats, float price, float discount, int departureairportId, int arrivalairportId, DateTime departureTime, DateTime arrivalTime)
        {
            this.flight_ID = flightid;
            guna2TextBox1.Text = number;
            guna2TextBox2.Text = seats.ToString();
            guna2TextBox5.Text = price.ToString();
            guna2TextBox4.Text = discount.ToString();
            guna2ComboBox2.SelectedValue = departureairportId;
            guna2ComboBox1.SelectedValue = arrivalairportId;
            guna2ComboBox3.SelectedValue = typeid;
            dateTimePicker2.Value = departureTime;
            dateTimePicker1.Value = arrivalTime;


        }


        private void LoadInternationalDepartureData()
        {
            DataTable dt = flightdl.GetAirport();
            DataView dv = new DataView(dt);
            dv.RowFilter = "lookup_id IN (13,14,15,18)";
            guna2ComboBox2.DataSource = dv;
            guna2ComboBox2.DisplayMember = "value";
            guna2ComboBox2.ValueMember = "lookup_id";
            guna2ComboBox2.SelectedIndex = -1;

        }
        private void LoadInternationalArrivalData1()
        {
            DataTable dt = flightdl.GetAirport();
            DataView dv = new DataView(dt);
            dv.RowFilter = "lookup_id IN (13,14,15,18)";
            guna2ComboBox1.DataSource = dv;
            guna2ComboBox1.DisplayMember = "value";
            guna2ComboBox1.ValueMember = "lookup_id";
            guna2ComboBox1.SelectedIndex = -1;
        }
        private void LoadDomesticDepartureData()
        {
            DataTable dt = flightdl.GetAirport();
            DataView dv = new DataView(dt);
            dv.RowFilter = "lookup_id IN (10,11,12)";
            guna2ComboBox2.DataSource = dv;
            guna2ComboBox2.DisplayMember = "value";
            guna2ComboBox2.ValueMember = "lookup_id";
            guna2ComboBox2.SelectedIndex = -1;

        }
        private void LoadDomesticArrivalData1()
        {
            DataTable dt = flightdl.GetAirport();
            DataView dv = new DataView(dt);
            dv.RowFilter = "lookup_id IN (10,11,12)";
            guna2ComboBox1.DataSource = dv;
            guna2ComboBox1.DisplayMember = "value";
            guna2ComboBox1.ValueMember = "lookup_id";
            guna2ComboBox1.SelectedIndex = -1;
        }

        private void LoadFlightType()
        {
            DataTable dt = flightdl.GetFlightType();
            guna2ComboBox3.DataSource = dt;
            guna2ComboBox3.DisplayMember = "value";
            guna2ComboBox3.ValueMember = "lookup_id";
            guna2ComboBox3.SelectedIndex = -1;
        }
        private void ClearTextFields()
        {
            guna2TextBox1.Text = "";
            guna2TextBox2.Text = "";
            guna2TextBox5.Text = "";
            guna2TextBox4.Text = "";
            guna2ComboBox1.ResetText();
            guna2ComboBox1.SelectedIndex = -1;

            guna2ComboBox2.ResetText();
            guna2ComboBox2.SelectedIndex = -1;

            guna2ComboBox3.ResetText();
            guna2ComboBox3.SelectedIndex = -1;
        }
    }
}
