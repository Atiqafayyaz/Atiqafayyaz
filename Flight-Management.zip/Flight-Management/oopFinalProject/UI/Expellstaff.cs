﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using oopFinalProject.BL;
using oopFinalProject.DL;

namespace oopFinalProject.UI
{
    public partial class Expellstaff : Form
    {
        staffDL staffdL = new staffDL();
        public Expellstaff()
        {
            InitializeComponent();
            this.DoubleBuffered = true;  // Smooth rendering
            this.SetStyle(ControlStyles.AllPaintingInWmPaint |
                          ControlStyles.UserPaint |
                          ControlStyles.OptimizedDoubleBuffer, true);
            this.UpdateStyles();
            LoadData();
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {

            if (dataGridView1.SelectedRows.Count == 1)
            {
                var selectedRow = dataGridView1.SelectedRows[0];
                int staffid = Convert.ToInt32(selectedRow.Cells["staff_id"].Value);
                bool isDeleted = staffdL.DeleteStaff(staffid);
                if (isDeleted)
                {
                    MessageBox.Show("staff Deleted Seccessfully");
                }
                else
                {
                    MessageBox.Show("Please try Again");
                }

            }
            else
            {
                MessageBox.Show("Please Select one row First");
            }
            LoadData();
        }
        private void LoadData()
        {

            DataTable staffData = staffdL.GetData();
            if (staffData != null)
            {

                dataGridView1.DataSource = staffData;
                if (dataGridView1.Columns["staff_id"] != null)
                {
                    dataGridView1.Columns["staff_id"].Visible = false;
                }
                if (dataGridView1.Columns["airport_id"] != null)
                {
                    dataGridView1.Columns["airport_id"].Visible = false;
                }
                if (dataGridView1.Columns["designation_id"] != null)
                {
                    dataGridView1.Columns["designation_id"].Visible = false;
                }
            }
            else
            {
                MessageBox.Show("No data available.");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {
            string search = guna2TextBox1.Text;
            DataTable searchData = staffdL.GetSearchData(search);
            if (searchData != null)
            {
                dataGridView1.DataSource = searchData;
            }

        }
    }
}
