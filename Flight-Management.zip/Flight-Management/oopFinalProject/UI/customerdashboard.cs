﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic.ApplicationServices;

namespace oopFinalProject.UI
{
    public partial class customerdashboard : Form
    {
        private int Userid;
        public customerdashboard(int userid)
        {
            InitializeComponent();
            this.DoubleBuffered = true;  // Smooth rendering avoid flickering
            this.SetStyle(ControlStyles.AllPaintingInWmPaint |
                          ControlStyles.UserPaint |
                          ControlStyles.OptimizedDoubleBuffer, true);
            this.UpdateStyles(); //ensure setting will apply
            Userid = userid;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        public void OpenFormInPanel(Form form)
        {
            adminpanel.Controls.Clear(); // Remove previous form
            form.TopLevel = false;  // Set as child control
            form.FormBorderStyle = FormBorderStyle.None;  // Remove window border
            form.Dock = DockStyle.Fill;  // Make it fill the panel
            adminpanel.Controls.Add(form);  // Add to panel
            form.Show();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            OpenFormInPanel(new bookflight(this.Userid));
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            OpenFormInPanel(new reservedflights(this.Userid));
        }

        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            OpenFormInPanel(new cancelbookflight());
        }

        private void linkLabel7_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            OpenFormInPanel(new submitfeedback(this.Userid));
        }

        private void linkLabel10_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            login login = new login();
            this.Hide();
            login.Show();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            OpenFormInPanel(new dashboard());
        }
    }
}
