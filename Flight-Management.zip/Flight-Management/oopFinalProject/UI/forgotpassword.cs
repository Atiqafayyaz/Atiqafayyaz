﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace oopFinalProject.UI
{
    public partial class forgotpassword : Form
    {
        AccountBL accountBL;
        public forgotpassword()
        {
            InitializeComponent();
            this.DoubleBuffered = true;  // Smooth rendering
            this.SetStyle(ControlStyles.AllPaintingInWmPaint |
                          ControlStyles.UserPaint |
                          ControlStyles.OptimizedDoubleBuffer, true);
            this.UpdateStyles();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            string username = Username.Text;
            string password = Password.Text;
            string confirmpassword = newpassword.Text;

            if (password == confirmpassword)
            {
                accountBL = new AccountBL(username, " ", password);
                MessageBox.Show(accountBL.Resetpassword());

            }
            else
            {
                MessageBox.Show("Both passwords not match");
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            login lo = new login();
            this.Hide();
            lo.Show();
        }
    }
}
