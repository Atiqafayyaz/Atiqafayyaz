﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using oopFinalProject.BL;
using oopFinalProject.DL;

namespace oopFinalProject.UI
{
    public partial class cancelbookflight : Form
    {
        BookingDL bookingdl = new BookingDL();
        public cancelbookflight()
        {
            InitializeComponent();
            this.DoubleBuffered = true;  // Smooth rendering avoid flickering
            this.SetStyle(ControlStyles.AllPaintingInWmPaint |
                          ControlStyles.UserPaint |
                          ControlStyles.OptimizedDoubleBuffer, true);
            this.UpdateStyles(); //ensure setting will apply
        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void guna2Button2_Click(object sender, EventArgs e)
        {
            string cnic = guna2TextBox1.Text;
            if (string.IsNullOrWhiteSpace(cnic) )
            {
                MessageBox.Show("Please Enter your CNIC");
                return;
            }
            if (!Regex.IsMatch(cnic, @"^\d+$") || cnic.StartsWith(" "))
            {
                MessageBox.Show("Invalid Inputs");
                return;
            }
            LoadData(cnic);
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                var selectedRow = dataGridView1.SelectedRows[0];
                int bookingId = Convert.ToInt32(selectedRow.Cells["booking_id"].Value);
                bool isDeleted = bookingdl.DeleteReservedFlight(bookingId);
                if (isDeleted)
                {
                    MessageBox.Show("Flight cancelled Seccessfully");
                }
                else
                {
                    MessageBox.Show("Please try Again");
                }

            }
            else
            {
                MessageBox.Show("Please Select one row First");
            }
        }
        private void LoadData(string cnic)
        {

            DataTable bookingData = bookingdl.GetReservedFlightData(cnic);
            if (bookingData != null)
            {

                dataGridView1.DataSource = bookingData;
                if (dataGridView1.Columns["booking_id"] != null)
                {
                    dataGridView1.Columns["booking_id"].Visible = false;
                }
            }
            else
            {
                MessageBox.Show("No data available.");
            }
        }

        private void guna2TextBox1_TextChanged_1(object sender, EventArgs e)
        {

        }
    }
}
