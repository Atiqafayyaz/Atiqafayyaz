﻿namespace oopFinalProject.UI
{
    partial class admindashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(admindashboard));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            pictureBox9 = new PictureBox();
            pictureBox8 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            guna2Panel4 = new Guna.UI2.WinForms.Guna2Panel();
            linkLabel10 = new LinkLabel();
            guna2Panel3 = new Guna.UI2.WinForms.Guna2Panel();
            label3 = new Label();
            guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            label2 = new Label();
            guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            label1 = new Label();
            linkLabel9 = new LinkLabel();
            linkLabel1 = new LinkLabel();
            linkLabel8 = new LinkLabel();
            linkLabel2 = new LinkLabel();
            linkLabel7 = new LinkLabel();
            linkLabel6 = new LinkLabel();
            linkLabel4 = new LinkLabel();
            linkLabel5 = new LinkLabel();
            adminpanel = new Panel();
            label7 = new Label();
            panel1 = new Panel();
            label5 = new Label();
            label4 = new Label();
            label6 = new Label();
            guna2GradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            guna2Panel4.SuspendLayout();
            guna2Panel3.SuspendLayout();
            guna2Panel2.SuspendLayout();
            guna2Panel1.SuspendLayout();
            adminpanel.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // guna2GradientPanel1
            // 
            guna2GradientPanel1.BackColor = Color.Purple;
            guna2GradientPanel1.BackgroundImage = (Image)resources.GetObject("guna2GradientPanel1.BackgroundImage");
            guna2GradientPanel1.BackgroundImageLayout = ImageLayout.Stretch;
            guna2GradientPanel1.BorderColor = Color.Red;
            guna2GradientPanel1.Controls.Add(pictureBox9);
            guna2GradientPanel1.Controls.Add(pictureBox8);
            guna2GradientPanel1.Controls.Add(pictureBox6);
            guna2GradientPanel1.Controls.Add(pictureBox7);
            guna2GradientPanel1.Controls.Add(pictureBox5);
            guna2GradientPanel1.Controls.Add(pictureBox4);
            guna2GradientPanel1.Controls.Add(pictureBox3);
            guna2GradientPanel1.Controls.Add(pictureBox2);
            guna2GradientPanel1.Controls.Add(pictureBox1);
            guna2GradientPanel1.Controls.Add(guna2Panel4);
            guna2GradientPanel1.Controls.Add(guna2Panel3);
            guna2GradientPanel1.Controls.Add(guna2Panel2);
            guna2GradientPanel1.Controls.Add(guna2Panel1);
            guna2GradientPanel1.Controls.Add(linkLabel9);
            guna2GradientPanel1.Controls.Add(linkLabel1);
            guna2GradientPanel1.Controls.Add(linkLabel8);
            guna2GradientPanel1.Controls.Add(linkLabel2);
            guna2GradientPanel1.Controls.Add(linkLabel7);
            guna2GradientPanel1.Controls.Add(linkLabel6);
            guna2GradientPanel1.Controls.Add(linkLabel4);
            guna2GradientPanel1.Controls.Add(linkLabel5);
            guna2GradientPanel1.CustomizableEdges = customizableEdges9;
            guna2GradientPanel1.Location = new Point(2, 3);
            guna2GradientPanel1.Name = "guna2GradientPanel1";
            guna2GradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges10;
            guna2GradientPanel1.Size = new Size(358, 770);
            guna2GradientPanel1.TabIndex = 0;
            // 
            // pictureBox9
            // 
            pictureBox9.BackColor = Color.Transparent;
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(90, 21);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(128, 94);
            pictureBox9.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox9.TabIndex = 21;
            pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.BackColor = Color.White;
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(65, 152);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(41, 38);
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 1;
            pictureBox8.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.BackColor = Color.White;
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(65, 676);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(41, 38);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 1;
            pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.BackColor = Color.White;
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(65, 630);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(41, 38);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 2;
            pictureBox7.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.White;
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(65, 520);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(41, 38);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 1;
            pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.White;
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(65, 472);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(41, 38);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 1;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.White;
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(65, 426);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(41, 38);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 1;
            pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.White;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(65, 315);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(41, 38);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 14;
            pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.White;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(65, 259);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(41, 38);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // guna2Panel4
            // 
            guna2Panel4.BackColor = Color.White;
            guna2Panel4.Controls.Add(linkLabel10);
            guna2Panel4.CustomizableEdges = customizableEdges1;
            guna2Panel4.Location = new Point(6, 724);
            guna2Panel4.Name = "guna2Panel4";
            guna2Panel4.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2Panel4.Size = new Size(329, 43);
            guna2Panel4.TabIndex = 13;
            // 
            // linkLabel10
            // 
            linkLabel10.AutoSize = true;
            linkLabel10.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            linkLabel10.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel10.LinkColor = Color.Purple;
            linkLabel10.Location = new Point(115, 0);
            linkLabel10.Name = "linkLabel10";
            linkLabel10.Size = new Size(78, 28);
            linkLabel10.TabIndex = 1;
            linkLabel10.TabStop = true;
            linkLabel10.Text = "Logout";
            linkLabel10.LinkClicked += linkLabel10_LinkClicked;
            // 
            // guna2Panel3
            // 
            guna2Panel3.BackColor = Color.White;
            guna2Panel3.Controls.Add(label3);
            guna2Panel3.CustomizableEdges = customizableEdges3;
            guna2Panel3.Location = new Point(3, 566);
            guna2Panel3.Name = "guna2Panel3";
            guna2Panel3.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2Panel3.Size = new Size(332, 43);
            guna2Panel3.TabIndex = 12;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.White;
            label3.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Purple;
            label3.Location = new Point(62, 0);
            label3.Name = "label3";
            label3.Size = new Size(102, 28);
            label3.TabIndex = 1;
            label3.Text = "View Info";
            // 
            // guna2Panel2
            // 
            guna2Panel2.BackColor = Color.White;
            guna2Panel2.Controls.Add(label2);
            guna2Panel2.CustomizableEdges = customizableEdges5;
            guna2Panel2.Location = new Point(3, 364);
            guna2Panel2.Name = "guna2Panel2";
            guna2Panel2.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2Panel2.Size = new Size(332, 43);
            guna2Panel2.TabIndex = 11;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.White;
            label2.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Purple;
            label2.Location = new Point(62, 9);
            label2.Name = "label2";
            label2.Size = new Size(145, 28);
            label2.TabIndex = 1;
            label2.Text = "Manage Staff";
            // 
            // guna2Panel1
            // 
            guna2Panel1.BackColor = Color.White;
            guna2Panel1.BorderThickness = 20;
            guna2Panel1.Controls.Add(label1);
            guna2Panel1.CustomizableEdges = customizableEdges7;
            guna2Panel1.Location = new Point(3, 196);
            guna2Panel1.Name = "guna2Panel1";
            guna2Panel1.ShadowDecoration.CustomizableEdges = customizableEdges8;
            guna2Panel1.Size = new Size(332, 43);
            guna2Panel1.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Purple;
            label1.Location = new Point(62, 9);
            label1.Name = "label1";
            label1.Size = new Size(163, 28);
            label1.TabIndex = 1;
            label1.Text = "Manage Flights";
            // 
            // linkLabel9
            // 
            linkLabel9.AutoSize = true;
            linkLabel9.BackColor = Color.Transparent;
            linkLabel9.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            linkLabel9.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel9.LinkColor = Color.White;
            linkLabel9.Location = new Point(121, 676);
            linkLabel9.Name = "linkLabel9";
            linkLabel9.Size = new Size(141, 28);
            linkLabel9.TabIndex = 8;
            linkLabel9.TabStop = true;
            linkLabel9.Text = "View Feedback";
            linkLabel9.LinkClicked += linkLabel9_LinkClicked;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.BackColor = Color.Transparent;
            linkLabel1.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            linkLabel1.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel1.LinkColor = Color.White;
            linkLabel1.Location = new Point(131, 154);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(68, 28);
            linkLabel1.TabIndex = 1;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Home";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // linkLabel8
            // 
            linkLabel8.AutoSize = true;
            linkLabel8.BackColor = Color.Transparent;
            linkLabel8.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            linkLabel8.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel8.LinkColor = Color.White;
            linkLabel8.Location = new Point(121, 630);
            linkLabel8.Name = "linkLabel8";
            linkLabel8.Size = new Size(139, 28);
            linkLabel8.TabIndex = 7;
            linkLabel8.TabStop = true;
            linkLabel8.Text = "View Bookings";
            linkLabel8.LinkClicked += linkLabel8_LinkClicked;
            // 
            // linkLabel2
            // 
            linkLabel2.AutoSize = true;
            linkLabel2.BackColor = Color.Transparent;
            linkLabel2.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            linkLabel2.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel2.LinkColor = Color.White;
            linkLabel2.Location = new Point(121, 269);
            linkLabel2.Name = "linkLabel2";
            linkLabel2.Size = new Size(104, 28);
            linkLabel2.TabIndex = 1;
            linkLabel2.TabStop = true;
            linkLabel2.Text = "Add Flight";
            linkLabel2.LinkClicked += linkLabel2_LinkClicked;
            // 
            // linkLabel7
            // 
            linkLabel7.AutoSize = true;
            linkLabel7.BackColor = Color.Transparent;
            linkLabel7.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            linkLabel7.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel7.LinkColor = Color.White;
            linkLabel7.Location = new Point(121, 520);
            linkLabel7.Name = "linkLabel7";
            linkLabel7.Size = new Size(97, 28);
            linkLabel7.TabIndex = 6;
            linkLabel7.TabStop = true;
            linkLabel7.Text = "View Staff";
            linkLabel7.LinkClicked += linkLabel7_LinkClicked;
            // 
            // linkLabel6
            // 
            linkLabel6.AutoSize = true;
            linkLabel6.BackColor = Color.Transparent;
            linkLabel6.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            linkLabel6.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel6.LinkColor = Color.White;
            linkLabel6.Location = new Point(121, 472);
            linkLabel6.Name = "linkLabel6";
            linkLabel6.Size = new Size(102, 28);
            linkLabel6.TabIndex = 5;
            linkLabel6.TabStop = true;
            linkLabel6.Text = "Expel Staff";
            linkLabel6.LinkClicked += linkLabel6_LinkClicked;
            // 
            // linkLabel4
            // 
            linkLabel4.AutoSize = true;
            linkLabel4.BackColor = Color.Transparent;
            linkLabel4.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            linkLabel4.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel4.LinkColor = Color.White;
            linkLabel4.Location = new Point(120, 315);
            linkLabel4.Name = "linkLabel4";
            linkLabel4.Size = new Size(108, 28);
            linkLabel4.TabIndex = 3;
            linkLabel4.TabStop = true;
            linkLabel4.Text = "View Flight";
            linkLabel4.LinkClicked += linkLabel4_LinkClicked;
            // 
            // linkLabel5
            // 
            linkLabel5.AutoSize = true;
            linkLabel5.BackColor = Color.Transparent;
            linkLabel5.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            linkLabel5.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel5.LinkColor = Color.White;
            linkLabel5.Location = new Point(121, 426);
            linkLabel5.Name = "linkLabel5";
            linkLabel5.Size = new Size(92, 28);
            linkLabel5.TabIndex = 4;
            linkLabel5.TabStop = true;
            linkLabel5.Text = "Hire Staff";
            linkLabel5.LinkClicked += linkLabel5_LinkClicked;
            // 
            // adminpanel
            // 
            adminpanel.BackgroundImageLayout = ImageLayout.Stretch;
            adminpanel.Controls.Add(label7);
            adminpanel.Controls.Add(panel1);
            adminpanel.Location = new Point(337, 3);
            adminpanel.Name = "adminpanel";
            adminpanel.Size = new Size(1138, 775);
            adminpanel.TabIndex = 1;
            adminpanel.Paint += adminpanel_Paint;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Indigo;
            label7.Font = new Font("Algerian", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.ControlLightLight;
            label7.Location = new Point(294, 196);
            label7.Name = "label7";
            label7.Size = new Size(495, 54);
            label7.TabIndex = 1;
            label7.Text = "NextWing Airlines";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Indigo;
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label6);
            panel1.Location = new Point(3, 3);
            panel1.Name = "panel1";
            panel1.Size = new Size(1132, 96);
            panel1.TabIndex = 0;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = SystemColors.ControlLightLight;
            label5.Location = new Point(181, 18);
            label5.Name = "label5";
            label5.Size = new Size(44, 32);
            label5.TabIndex = 1;
            label5.Text = "___";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.ControlLightLight;
            label4.Location = new Point(29, 29);
            label4.Name = "label4";
            label4.Size = new Size(159, 38);
            label4.TabIndex = 1;
            label4.Text = "Dashboard";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = SystemColors.ControlLightLight;
            label6.Location = new Point(181, 29);
            label6.Name = "label6";
            label6.Size = new Size(44, 32);
            label6.TabIndex = 2;
            label6.Text = "___";
            // 
            // admindashboard
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(1477, 777);
            Controls.Add(adminpanel);
            Controls.Add(guna2GradientPanel1);
            Name = "admindashboard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "admindashboard";
            guna2GradientPanel1.ResumeLayout(false);
            guna2GradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            guna2Panel4.ResumeLayout(false);
            guna2Panel4.PerformLayout();
            guna2Panel3.ResumeLayout(false);
            guna2Panel3.PerformLayout();
            guna2Panel2.ResumeLayout(false);
            guna2Panel2.PerformLayout();
            guna2Panel1.ResumeLayout(false);
            guna2Panel1.PerformLayout();
            adminpanel.ResumeLayout(false);
            adminpanel.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private LinkLabel linkLabel9;
        private LinkLabel linkLabel1;
        private LinkLabel linkLabel8;
        private LinkLabel linkLabel2;
        private LinkLabel linkLabel7;
        private LinkLabel linkLabel6;
        private LinkLabel linkLabel4;
        private LinkLabel linkLabel5;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Label label1;
        private LinkLabel linkLabel10;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel4;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel3;
        private Label label3;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Label label2;
        private Panel adminpanel;
        private PictureBox pictureBox1;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private PictureBox pictureBox8;
        private PictureBox pictureBox6;
        private PictureBox pictureBox7;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private PictureBox pictureBox9;
        private Panel panel1;
        private Label label4;
        private Label label7;
        private Label label5;
        private Label label6;
    }
}