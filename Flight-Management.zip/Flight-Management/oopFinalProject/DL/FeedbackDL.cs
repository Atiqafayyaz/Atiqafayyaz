﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayer;
using Microsoft.VisualBasic.ApplicationServices;
using oopFinalProject.BL;
namespace oopFinalProject.DL
{
    public class FeedbackDL
    {

        public bool SubmitFeedback(string Feedback , int userid)
        {
            string query = $"INSERT INTO feedback (user_id , description)" +
                           $"VALUES ({userid}, '{Feedback}' );";

            int result1 = DatabaseHelper.Instance.Update(query);

            return result1 > 0;
        }
        public string Query()
        {
            string query = $"SELECT u.username As name , f.description " +
                          $"FROM feedback f  join users u ON f.user_id = u.user_id ";
            return query;

        }
        public DataTable GetData()
        {
            DataTable dt = new DataTable();
            string query = Query();
            using (var reader = DatabaseHelper.Instance.GetData(query))
            {
                dt.Load(reader);
            }

            return dt;
        }
    
     public DataTable GetSearchData(string search)
        {
            DataTable dt2 = new DataTable();
            string query;

            if (string.IsNullOrWhiteSpace(search))
            {

                query = Query();
            }

            else
            {

                query = $"SELECT u.username As name , f.description " +
                          $"FROM feedback f  join users u ON f.user_id = u.user_id  " +
                          $" WHERE u.username LIKE '%" + search + "%'";

            }
            using (var reader = DatabaseHelper.Instance.GetData(query))
            {
                dt2.Load(reader);
            }

            return dt2;
        }
    }
}
