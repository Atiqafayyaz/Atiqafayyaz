﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayer;
using MySql.Data.MySqlClient;

namespace oopFinalProject.DL
{
     public class BookingDL
    {
        public string Query()
        {
            string query = $"SELECT b.Name , b.CNIC ," +
                          $" f.flight_number ," +
                          $" CASE WHEN f.type_id = 16 THEN 'international' " +
                          $" WHEN f.type_id = 17 THEN 'domestic' " +
                          $" END AS Type ," +
                          $"CASE WHEN b.status_id = 1 THEN 'booked' " +
                          $" WHEN b.status_id = 2 THEN 'cancelled' " +
                          $" WHEN b.status_id = 3 THEN 'completed' " +
                          $" END AS status  FROM booking b join flight f ON f.flight_id = b.flight_id ";
            return query;

        }
        public DataTable GetData()
        {
            DataTable dt = new DataTable();
            string query = Query();
            using (var reader = DatabaseHelper.Instance.GetData(query))
            {
                dt.Load(reader);
            }

            return dt;
        }
        public DataTable GetSearchData(string search)
        {
            DataTable dt2 = new DataTable();
            string query;

            if (string.IsNullOrWhiteSpace(search))
            {

                query = Query();
            }

            else
            {

                query = $"SELECT b.Name , b.CNIC ," +
                           $" f.flight_number ," +
                           $" CASE WHEN f.type_id = 16 THEN 'international' " +
                           $" WHEN f.type_id = 17 THEN 'domestic' " +
                           $" END AS Type ," +
                           $"CASE WHEN b.status_id = 1 THEN 'booked' " +
                           $" WHEN b.status_id = 2 THEN 'cancelled' " +
                           $" WHEN b.status_id = 3 THEN 'completed' " +
                           $" END AS status  FROM booking b join flight f ON f.flight_id = b.flight_id " +
                           $" WHERE b.Name LIKE '%" + search + "%'";


            }
            using (var reader = DatabaseHelper.Instance.GetData(query))
            {
                dt2.Load(reader);
            }

            return dt2;
        }
        public DataTable GetflightData()
        {
            DataTable dt = new DataTable();
            string query = $"select f.flight_id, f.flight_number , " +
                           $" CASE WHEN f.type_id = 16 THEN 'international' " +
                           $" WHEN f.type_id = 17 THEN 'domestic' " +
                           $" END AS Type ," +
                           $"f.price , f.discount_percentage , f.price_after_discount, " +
                           $" CASE WHEN f.departure_airport_id = 10 THEN 'lahore' " +
                           $" WHEN f.departure_airport_id = 11 THEN 'karachi' " +
                           $" WHEN f.departure_airport_id = 12 THEN 'islamabad' " +
                           $" WHEN f.departure_airport_id = 13 THEN 'US' " +
                           $" WHEN f.departure_airport_id = 14 THEN 'UK' " +
                           $" WHEN f.departure_airport_id = 15 THEN 'UAE' " +
                           $" WHEN f.departure_airport_id = 18  THEN 'Pakistan' " +
                           $" END AS Departure_Airport ," +
                           $" CASE WHEN f.arrival_airport_id = 10 THEN 'lahore' " +
                           $" WHEN f.arrival_airport_id = 11 THEN 'karachi' " +
                           $" WHEN f.arrival_airport_id = 12 THEN 'islamabad' " +
                           $" WHEN f.arrival_airport_id = 13 THEN 'US' " +
                           $" WHEN f.arrival_airport_id = 14 THEN 'UK' " +
                           $" WHEN f.arrival_airport_id = 15 THEN 'UAE' " +
                           $" WHEN f.arrival_airport_id = 18  THEN 'Pakistan' " +
                           $" END AS  Arrival_Airport ," +
                           $" f.departure_time , f.arrival_time,f.Visarequired,f.cnicRequired FROM flight f";

            using (var reader = DatabaseHelper.Instance.GetData(query))
            {
                dt.Load(reader);
            }

            return dt;
        }
        public DataTable Getairport()
        {
            DataTable dt1 = new DataTable();
            string query = $"SELECT lookup_id , value  FROM lookup WHERE category = 'airport'";

            using (var reader = DatabaseHelper.Instance.GetData(query))
            {
                dt1.Load(reader);
                return dt1;
            }
        }
        public DataTable LoadFilteredData(int departureID,int arrivalID)
        {
            DataTable dt = new DataTable();
            string query = $"select f.flight_id, f.flight_number , " +
                           $" CASE WHEN f.type_id = 16 THEN 'international' " +
                           $" WHEN f.type_id = 17 THEN 'domestic' " +
                           $" END AS Type ," +
                           $"f.price , f.discount_percentage , f.price_after_discount, " +
                           $" CASE WHEN f.departure_airport_id = 10 THEN 'lahore' " +
                           $" WHEN f.departure_airport_id = 11 THEN 'karachi' " +
                           $" WHEN f.departure_airport_id = 12 THEN 'islamabad' " +
                           $" WHEN f.departure_airport_id = 13 THEN 'US' " +
                           $" WHEN f.departure_airport_id = 14 THEN 'UK' " +
                           $" WHEN f.departure_airport_id = 15 THEN 'UAE' " +
                           $" WHEN f.departure_airport_id = 18  THEN 'Pakistan' " +
                           $" END AS Departure_Airport ," +
                           $" CASE WHEN f.arrival_airport_id = 10 THEN 'lahore' " +
                           $" WHEN f.arrival_airport_id = 11 THEN 'karachi' " +
                           $" WHEN f.arrival_airport_id = 12 THEN 'islamabad' " +
                           $" WHEN f.arrival_airport_id = 13 THEN 'US' " +
                           $" WHEN f.arrival_airport_id = 14 THEN 'UK' " +
                           $" WHEN f.arrival_airport_id = 15 THEN 'UAE' " +
                           $" WHEN f.arrival_airport_id = 18  THEN 'Pakistan' " +
                           $" END AS  Arrival_Airport ," +
                           $" f.departure_time , f.arrival_time,f.Visarequired,f.cnicRequired FROM flight f WHERE f.departure_airport_id = {departureID} AND f.arrival_airport_id = {arrivalID}";

            using (var reader = DatabaseHelper.Instance.GetData(query))
            {
                dt.Load(reader);
            }

            return dt;
        }

        
        public bool Bookflight(int flightID ,string Name, string CNIC,int userid)
        {
            try
            {
                string query = $"INSERT INTO booking (flight_id ,user_id, Name , CNIC)" +
                              $"VALUES ({flightID},{userid}, '{Name}' , '{CNIC}');";

                int result1 = DatabaseHelper.Instance.Update(query);

                return result1 > 0;
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1062) // Duplicate entry
                    throw new Exception("Already Booked");
                else
                    throw; // Let other errors bubble up
            }
        }

        public DataTable GetReservedFlightData(string cnic)
        {
            DataTable dt = new DataTable();
            string query = $"select b.booking_id ,b.Name, f.flight_number , " +
                           $" CASE WHEN f.type_id = 16 THEN 'international' " +
                           $" WHEN f.type_id = 17 THEN 'domestic' " +
                           $" END AS Type ," +
                           $" f.price_after_discount as Price, " +
                           $" CASE WHEN f.departure_airport_id = 10 THEN 'lahore' " +
                           $" WHEN f.departure_airport_id = 11 THEN 'karachi' " +
                           $" WHEN f.departure_airport_id = 12 THEN 'islamabad' " +
                           $" WHEN f.departure_airport_id = 13 THEN 'US' " +
                           $" WHEN f.departure_airport_id = 14 THEN 'UK' " +
                           $" WHEN f.departure_airport_id = 15 THEN 'UAE' " +
                           $" WHEN f.departure_airport_id = 18  THEN 'Pakistan' " +
                           $" END AS Departure_Airport ," +
                           $" CASE WHEN f.arrival_airport_id = 10 THEN 'lahore' " +
                           $" WHEN f.arrival_airport_id = 11 THEN 'karachi' " +
                           $" WHEN f.arrival_airport_id = 12 THEN 'islamabad' " +
                           $" WHEN f.arrival_airport_id = 13 THEN 'US' " +
                           $" WHEN f.arrival_airport_id = 14 THEN 'UK' " +
                           $" WHEN f.arrival_airport_id = 15 THEN 'UAE' " +
                           $" WHEN f.arrival_airport_id = 18  THEN 'Pakistan' " +
                           $" END AS  Arrival_Airport ," +
                           $" f.departure_time , f.arrival_time ,f.Visarequired,f.cnicRequired, " +
                           $"CASE WHEN b.status_id = 1 THEN 'booked' " +
                           $"WHEN b.status_id = 2 THEN 'cancelled' " +
                           $"WHEN b.status_id = 3 THEN 'completed' " +
                           $"END AS Status  " +
                           $" FROM flight f join booking b ON b.flight_id = f.flight_id" +
                           $" WHERE b.CNIC = '{cnic}'";

            using (var reader = DatabaseHelper.Instance.GetData(query))
            {
                dt.Load(reader);
            }

            return dt;
        }
         public bool DeleteReservedFlight(int bookingId)
        {
          
            string query = $"UPDATE booking SET status_id = 2 WHERE booking_id = {bookingId}";

            int result = DatabaseHelper.Instance.Update(query);

            return result > 0;
        }
        public int GetNotified(int UserID)
        {
            string query = $"select count(booking_id) from booking where flight_id is null  and user_id = {UserID}";
            int result = DatabaseHelper.Instance.ExecuteScalar<int>(query);
            return result;
        }
        public void DeleteCancelFlight(int UserID)
        {

            string query = $"Delete from booking where flight_id is null and user_id = {UserID}";
            DatabaseHelper.Instance.Update(query);         
        }


    }
}
