﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using DataLayer;
using MySql.Data.MySqlClient;
using oopFinalProject.BL;

namespace oopFinalProject.DL
{
     public  class FlightDL
    {
        public bool AddInternationalFlight(string VisaRequired ,string number, int seats, float price, double price_after_tax,float discount, int departureID, int arrivalID, int typeID, DateTime departureTime, DateTime arrivalTime)
        {
            try
            {
                string query = $"INSERT INTO flight (flight_number , type_id , total_seats , price , Price_after_Tax " +
                               $", discount_percentage , departure_airport_id , arrival_airport_id , departure_time , arrival_time,Visarequired) " +
                               $" VALUES ('{number}' , {typeID} , {seats} , {price} ,{price_after_tax} " +
                               $"  , {discount} , {departureID} , {arrivalID} , '{departureTime.ToString("yyyy-MM-dd HH:mm:ss")}' , '{arrivalTime.ToString("yyyy-MM-dd HH:mm:ss")}','{VisaRequired}') ";

                int result1 = DatabaseHelper.Instance.Update(query);

                return result1 > 0;
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1062) // Duplicate entry
                    throw new Exception("Already Found");
                else
                    throw; // Let other errors bubble up
            }
        }
        public bool AddDomesticFlight(string CNICRequired, string number, int seats, float price, double price_after_tax, float discount, int departureID, int arrivalID, int typeID, DateTime departureTime, DateTime arrivalTime)
        {
            try
            {
                string query = $"INSERT INTO flight (flight_number , type_id , total_seats , price , Price_after_Tax " +
                               $", discount_percentage , departure_airport_id , arrival_airport_id , departure_time , arrival_time,cnicRequired) " +
                               $" VALUES ('{number}' , {typeID} , {seats} , {price} ,{price_after_tax} " +
                               $"  , {discount} , {departureID} , {arrivalID} , '{departureTime.ToString("yyyy-MM-dd HH:mm:ss")}' , '{arrivalTime.ToString("yyyy-MM-dd HH:mm:ss")}','{CNICRequired}') ";

                int result1 = DatabaseHelper.Instance.Update(query);

                return result1 > 0;
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1062) // Duplicate entry
                    throw new Exception("Already Found");
                else
                    throw; // Let other errors bubble up
            }
        }

        public bool UpdateFlight(int flightid ,string number, int seats, float price, double price_after_tax, float discount, int departureID, int arrivalID, int typeID, DateTime departureTime, DateTime arrivalTime)
        {
            try
            {
                string query = $"UPDATE flight SET flight_number = '{number}', type_id = {typeID}, total_seats = {seats}, " +
                       $" price = {price}, Price_after_Tax = {price_after_tax}, discount_percentage = {discount}, " +
                       $"departure_airport_id = {departureID} , arrival_airport_id = {arrivalID} , departure_time = '{departureTime.ToString("yyyy-MM-dd HH:mm:ss")}' , " +
                       $" arrival_time = '{arrivalTime.ToString("yyyy-MM-dd HH:mm:ss")}' WHERE flight_id = {flightid}";
                int result1 = DatabaseHelper.Instance.Update(query);

                return result1 > 0;
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1062) // Duplicate entry
                    throw new Exception("Already Found");
                else
                    throw; // Let other errors bubble up
            }
        }
       
        public bool DeleteFlight(int flightId)
        {
            string query = $"delete from flight where flight_id = {flightId}";

            int result = DatabaseHelper.Instance.Update(query);

            return result > 0;
        }
        public string GetQuery()
        {
            string query = $"SELECT flight_id,flight_number , " +
                            $"type_id, " +
                            $"CASE WHEN type_id = 16 THEN 'International'" +
                            $" WHEN type_id = 17 THEN 'Domestic' " +
                            $" END AS Type ," +
                            $"total_seats , available_seats , " +
                            $"Price , Price_after_tax , discount_percentage , price_after_discount, " +
                            $"CASE WHEN departure_airport_id = 10 THEN 'Lahore'" +
                            $"WHEN departure_airport_id = 11  THEN 'Karachi' " +
                            $"WHEN departure_airport_id = 12  THEN 'Islamabad' " +
                            $" WHEN departure_airport_id = 13  THEN 'US' " +
                            $"WHEN departure_airport_id = 14  THEN 'UK' " +
                            $" WHEN departure_airport_id = 15  THEN 'UAE' " +
                            $" WHEN departure_airport_id = 18  THEN 'Pakistan' " +
                            $"END AS Departure_Airport, " +
                            $"CASE WHEN arrival_airport_id = 10  THEN 'Lahore' " +
                            $"WHEN arrival_airport_id = 11  THEN 'Karachi' " +
                            $"WHEN arrival_airport_id = 12  THEN 'Islamabad' " +
                            $" WHEN arrival_airport_id = 13  THEN 'US' " +
                            $"WHEN arrival_airport_id = 14  THEN 'UK' " +
                            $" WHEN arrival_airport_id = 15  THEN 'UAE' " +
                            $" WHEN arrival_airport_id = 18  THEN 'Pakistan' " +
                            $"END AS Arrival_Airport, " +
                            $"departure_time , arrival_time , departure_airport_id , arrival_airport_id,Visarequired,cnicRequired " +
                            $"from flight";
            return query;

        }

        public DataTable GetData()
        {
            DataTable dt = new DataTable();
            string query = GetQuery();
            using (var reader = DatabaseHelper.Instance.GetData(query))
            {
                dt.Load(reader);
            }

            return dt;
        }

        public DataTable GetSearchData(string search)
        {
            DataTable dt2 = new DataTable();
            string query;

            if (string.IsNullOrWhiteSpace(search))
            {

                query = GetQuery();
            }

            else
            {

                query =    $"SELECT flight_id,flight_number , " +
                            $"type_id, " +
                            $"CASE WHEN type_id = 16 THEN 'International'" +
                            $" WHEN type_id = 17 THEN 'Domestic' " +
                            $" END AS Type ," +
                            $"total_seats , available_seats ," +
                            $"Price , Price_after_tax , discount_percentage , price_after_discount, " +
                            $"CASE WHEN departure_airport_id = 10 THEN 'Lahore'" +
                            $"WHEN departure_airport_id = 11  THEN 'Karachi' " +
                            $"WHEN departure_airport_id = 12  THEN 'Islamabad' " +
                            $" WHEN departure_airport_id = 13  THEN 'US' " +
                            $"WHEN departure_airport_id = 14  THEN 'UK' " +
                            $" WHEN departure_airport_id = 15  THEN 'UAE' " +
                            $" WHEN departure_airport_id = 18  THEN 'Pakistan' " +
                            $"END AS Departure_Airport, " +
                            $"CASE WHEN arrival_airport_id = 10  THEN 'Lahore' " +
                            $"WHEN arrival_airport_id = 11  THEN 'Karachi' " +
                            $"WHEN arrival_airport_id = 12  THEN 'Islamabad' " +
                            $" WHEN arrival_airport_id = 13  THEN 'US' " +
                            $"WHEN arrival_airport_id = 14  THEN 'UK' " +
                            $" WHEN arrival_airport_id = 15  THEN 'UAE' " +
                             $" WHEN arrival_airport_id = 18  THEN 'Pakistan' " +
                            $"END AS Arrival_Airport, " +
                            $"departure_time , arrival_time , departure_airport_id , arrival_airport_id,Visarequired,cnicRequired " +
                            $"from flight WHERE flight_number LIKE '%" + search + "%'";


            }
            using (var reader = DatabaseHelper.Instance.GetData(query))
            {
                dt2.Load(reader);
            }

            return dt2;
        }




        public DataTable GetAirport()
        {
            DataTable dt = new DataTable();
            string query = $"select value , lookup_id from lookup where category = 'airport'";
            using (var reader = DatabaseHelper.Instance.GetData(query))
            {
                dt.Load(reader);
                return dt;

            }
        }
       
        public DataTable GetFlightType()
        {
            DataTable dt = new DataTable();
            string query = $"select value , lookup_id from lookup where category = 'type'";
            using (var reader = DatabaseHelper.Instance.GetData(query))
            {
                dt.Load(reader);
                return dt;

            }
        }


    }
    
}
