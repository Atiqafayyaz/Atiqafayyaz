﻿using MySql.Data.MySqlClient;
using Org.BouncyCastle.Tls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
    public class DatabaseHelper
    {
        private String serverName = "127.0.0.1";
        private String port = "3306";
        private String databaseName = "finalprojectoop";
        private String databaseUser = "root";
        private String databasePassword = "atiqa@123atiqa@123";

        private DatabaseHelper() { }

        private static DatabaseHelper _instance;
        public static DatabaseHelper Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new DatabaseHelper();
                return _instance;
            }
        }
        public MySqlConnection GetConnection()
        {
            string connectionString = $"server={serverName};port={port};user={databaseUser};database={databaseName};password={databasePassword};SslMode=Required;";
            var connection = new MySqlConnection(connectionString);
            connection.Open();

            return connection;
        }

        public MySqlDataReader GetData(string query)
        {
            using (var connection = GetConnection())
            {
                using (var command = new MySqlCommand(query, GetConnection()))
                {
                    return command.ExecuteReader();
                }
            }

        }
        public object ExecuteScalar(string query, Dictionary<string, object> parameters)
        {
            object result = null;

            using (var connection = GetConnection())
            {
                using (var command = new MySqlCommand(query, connection))
                {

                    foreach (var param in parameters)
                    {
                        command.Parameters.AddWithValue(param.Key, param.Value);
                    }

                    result = command.ExecuteScalar();
                }
            }

            return result;
        }

        public int Update(string query)
        {
            using (var connection = GetConnection())
            {
                using (var command = new MySqlCommand(query, GetConnection()))
                {
                    return command.ExecuteNonQuery();
                }
            }

        }
        public T ExecuteScalar<T>(string query)
        {
            using (var connection = GetConnection())
            {

                using (var command = new MySqlCommand(query, connection))
                {

                    var result = command.ExecuteScalar();


                    if (result == DBNull.Value || result == null)
                    {
                        return default(T);
                    }


                    return (T)Convert.ChangeType(result, typeof(T));
                }
            }
        }

    }
}

