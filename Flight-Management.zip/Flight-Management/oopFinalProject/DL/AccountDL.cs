﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayer;
using Microsoft.VisualBasic.ApplicationServices;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
namespace oopFinalProject.DL
{
    public class AccountDL
    {
        public bool AddAccount (string username , string email , string password)
        {
            try
            {
                string query = $"INSERT INTO users (username, email, hash_password)" +
                               $"VALUES ('{username}', '{email}' , '{password}' );";

                int result1 = DatabaseHelper.Instance.Update(query);

                return result1 > 0;
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1062) // Duplicate entry
                    throw new Exception("Use Different Email");
                else
                    throw; // Let other errors bubble up
            }
        }

        public string getUserHashPassword(string email)
        {
            string query = $"SELECT hash_password FROM users WHERE email = '{email}'";

            return DatabaseHelper.Instance.ExecuteScalar<string>(query);

        }
        public int GetEmailCount(string email)
        {
            string query = $"select count(email) from users where email = '{email}' ";

            return DatabaseHelper.Instance.ExecuteScalar<int>(query);
        }
        public int getuserid(string email)
        {
            string query = $"SELECT user_id FROM users WHERE email = '{email}'";

            return DatabaseHelper.Instance.ExecuteScalar<int>(query);

        }
        public bool ResetPassword(string Username, string Password)
        {
            string query = $"UPDATE users SET  hash_password = '{Password}'" +
                           $" WHERE username = '{Username}'";

            int result = DatabaseHelper.Instance.Update(query);

            return result > 0;


        }
    }
}
