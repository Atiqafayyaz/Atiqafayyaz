﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using DataLayer;
using MySql.Data.MySqlClient;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace oopFinalProject.DL
{
    public class staffDL
    {
        public DataTable Getdesignation()
        {
            DataTable dt1 = new DataTable();
            string query = $"SELECT lookup_id , value  FROM lookup WHERE category = 'designation'";

            using (var reader = DatabaseHelper.Instance.GetData(query))
            {
                dt1.Load(reader);

                return dt1;
            }

        }
        public DataTable Getairport()
        {
            DataTable dt1 = new DataTable();
            string query = $"SELECT lookup_id , value  FROM lookup WHERE category = 'airport'";

            using (var reader = DatabaseHelper.Instance.GetData(query))
            {
                dt1.Load(reader);
                return dt1;
            }
        }

        public bool DeleteStaff(int staffId)
        {
            string query = $"UPDATE staff SET status_id = 4 WHERE staff_id = {staffId}";

            int result = DatabaseHelper.Instance.Update(query);

            return result > 0;
        }
        public DataTable GetData()
        {
            DataTable dt = new DataTable();
            string query = $"SELECT staff_id , name , address, contact , " +
                            $"airport_id , designation_id, "+
                            $"CASE WHEN airport_id = 10  THEN 'Lahore'  " +
                            $"WHEN airport_id = 11  THEN 'Karachi' " +
                            $"WHEN airport_id = 12  THEN 'Islamabad' " +
                            $" WHEN airport_id = 13  THEN 'US' " +
                            $"WHEN airport_id = 14  THEN 'UK' " +
                            $" WHEN airport_id = 15  THEN 'UAE' " +
                            $"END AS Airport, " +
                            $"CASE WHEN designation_id = 6  THEN 'Pilot'  " +
                            $"WHEN designation_id = 7  THEN 'cabin-crew' " +
                            $"WHEN designation_id = 8  THEN 'ground-crew' " +
                            $" WHEN designation_id = 9  THEN 'check-in-officer' " +
                            $"END AS designation, " +
                            $"date_of_joining FROM staff WHERE status_id = 5";

            using (var reader = DatabaseHelper.Instance.GetData(query))
            {
                dt.Load(reader);
            }

            return dt;
        }
        public DataTable GetEntireData()
        {
            DataTable dt = new DataTable();
            string query = $"SELECT staff_id , name , address, contact , " +
                            $"airport_id , designation_id, " +
                            $"CASE WHEN airport_id = 10  THEN 'Lahore'  " +
                            $"WHEN airport_id = 11  THEN 'Karachi' " +
                            $"WHEN airport_id = 12  THEN 'Islamabad' " +
                            $" WHEN airport_id = 13  THEN 'US' " +
                            $"WHEN airport_id = 14  THEN 'UK' " +
                            $" WHEN airport_id = 15  THEN 'UAE' " +
                            $" WHEN airport_id = 18  THEN 'Pakistan' " +
                            $"END AS Airport, " +
                            $"CASE WHEN designation_id = 6  THEN 'Pilot'  " +
                            $"WHEN designation_id = 7  THEN 'cabin-crew' " +
                            $"WHEN designation_id = 8  THEN 'ground-crew' " +
                            $" WHEN designation_id = 9  THEN 'check-in-officer' " +
                            $"END AS designation, " +
                            $"date_of_joining," +
                            $"CASE WHEN status_id = 4 THEN 'inactive' " +
                            $"WHEN status_id = 5 THEN 'active' " +
                            $"END AS Status FROM staff ";

            using (var reader = DatabaseHelper.Instance.GetData(query))
            {
                dt.Load(reader);
            }

            return dt;
        }
        public DataTable GetSearchData(string search)
        {
            DataTable dt2 = new DataTable();
            string query;

            if (string.IsNullOrWhiteSpace(search))
            {

                query = $"SELECT staff_id , name , address, contact , " +
                            $"airport_id , designation_id, " +
                            $"CASE WHEN airport_id = 10  THEN 'Lahore'  " +
                            $"WHEN airport_id = 11  THEN 'Karachi' " +
                            $"WHEN airport_id = 12  THEN 'Islamabad' " +
                            $" WHEN airport_id = 13  THEN 'US' " +
                            $"WHEN airport_id = 14  THEN 'UK' " +
                            $" WHEN airport_id = 15  THEN 'UAE' " +
                            $" WHEN airport_id = 18  THEN 'Pakistan' " +
                            $"END AS Airport, " +
                            $"CASE WHEN designation_id = 6  THEN 'Pilot'  " +
                            $"WHEN designation_id = 7  THEN 'cabin-crew' " +
                            $"WHEN designation_id = 8  THEN 'ground-crew' " +
                            $" WHEN designation_id = 9  THEN 'check-in-officer' " +
                            $"END AS designation, " +
                            $"date_of_joining FROM staff WHERE status_id = 5";
            }

            else
            {

                query = $"SELECT staff_id , name , address, contact , " +
                             $"airport_id , designation_id, " +
                            $"CASE WHEN airport_id = 10  THEN 'Lahore'  " +
                            $"WHEN airport_id = 11  THEN 'Karachi' " +
                            $"WHEN airport_id = 12  THEN 'Islamabad' " +
                            $" WHEN airport_id = 13  THEN 'US' " +
                            $"WHEN airport_id = 14  THEN 'UK' " +
                            $" WHEN airport_id = 15  THEN 'UAE' " +
                            $" WHEN airport_id = 18  THEN 'Pakistan' " +
                            $"END AS Airport, " +
                            $"CASE WHEN designation_id = 6  THEN 'Pilot'  " +
                            $"WHEN designation_id = 7  THEN 'cabin-crew' " +
                            $"WHEN designation_id = 8  THEN 'ground-crew' " +
                            $" WHEN designation_id = 9  THEN 'check-in-officer' " +
                            $"END AS designation, " +
                            $"date_of_joining FROM staff WHERE status_id = 5 and name LIKE '%" + search + "%'";


            }
                using (var reader = DatabaseHelper.Instance.GetData(query))
                {
                    dt2.Load(reader);
                }

                return dt2;
            }
    


        public bool AddStaff(string Name , string Contact , string Address , int DesignationID , int AirportID , string Date)
        {
            try
            {
                DateTime parsedDate = DateTime.ParseExact(Date, "dd MMM yyyy", CultureInfo.InvariantCulture);
                string formattedDate = parsedDate.ToString("yyyy-MM-dd");

                string query = $"INSERT INTO staff (name , address , contact , airport_id , designation_id , date_of_joining)" +
                              $"VALUES ('{Name}', '{Address}' , '{Contact}' , {AirportID}, {DesignationID} , '{formattedDate}' );";

                int result1 = DatabaseHelper.Instance.Update(query);

                return result1 > 0;
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1062) // Duplicate entry
                    throw new Exception("Already Found");
                else
                    throw; // Let other errors bubble up
            }
        }

        public bool UpdateStaff(int staffid , string Name, string Contact, string Address, int DesignationID, int AirportID, string Date)
        {
            try
            {
                DateTime parsedDate = DateTime.ParseExact(Date, "dd MMM yyyy", CultureInfo.InvariantCulture);
                string formattedDate = parsedDate.ToString("yyyy-MM-dd");

                string query = $"UPDATE staff SET name = '{Name}', contact = '{Contact}', address = '{Address}', " +
                       $"designation_id = {DesignationID}, airport_id = {AirportID}, " +
                       $"date_of_joining = '{formattedDate}' WHERE staff_id = {staffid}";

                int result = DatabaseHelper.Instance.Update(query);

                return result > 0;
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1062) // Duplicate entry
                    throw new Exception("Already Found");
                else
                    throw; // Let other errors bubble up
            }
        }
    }
}
