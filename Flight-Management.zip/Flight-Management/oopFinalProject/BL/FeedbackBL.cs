﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Linq;
using oopFinalProject.DL;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace oopFinalProject.BL
{
    public class FeedbackBL
    {
        public string Feedback {  get; private set; }
        public FeedbackDL feedbackdl;

        public FeedbackBL(string feedback)
        {
            Feedback = feedback;
            feedbackdl = new FeedbackDL();
            
        }

        public string SubmitFeedback(int userid)
        {
            if(!ValidateData())
            {
                return "Invalid Input";
            }

            bool flag = feedbackdl.SubmitFeedback(Feedback , userid);
            if (flag)
            {
                return "Feedback Submit Successfully";
            }
            else
            {
                return "please try again";
            }

        }

        private bool ValidateData()
        {
            if (string.IsNullOrWhiteSpace(Feedback) || !Regex.IsMatch(Feedback, @"^[a-zA-Z\s]+$") )
            {
                return false;
            }
            return true;
        }
    }
}
