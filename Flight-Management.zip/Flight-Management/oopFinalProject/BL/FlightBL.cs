﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Linq;
using oopFinalProject.DL;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace oopFinalProject.BL
{
    public abstract class FlightBL
    {
        public FlightDL flightdl = new FlightDL();
        public string Number { get; protected set; }
        public int Seats { get; protected set; }
        public float Price { get; protected set; }
        public float Discount { get; protected set; }
        public int DepartureID { get; protected set; }
        public int ArrivalID { get; protected set; }
        public int TypeID { get; protected set; }
        public DateTime DepartureTime { get; protected set; }
        public DateTime ArrivalTime { get; protected set; }
        public double Price_after_Tax { get; protected set; }


        public FlightBL(string number, int seats , float price , float discount , int departureID , int arrivalID , int typeID, DateTime departureTime, DateTime arrivalTime )
        {
            Number = number;
            Seats = seats;
            Price = price;
            Discount = discount;
            DepartureID = departureID;
            ArrivalID = arrivalID;
            TypeID = typeID;
            DepartureTime = departureTime;
            ArrivalTime = arrivalTime;
            Price_after_Tax = GetpriceafterTax();
            
            
        }
        public abstract double CalculateTax();

        public double GetpriceafterTax()
        {
            return Price + CalculateTax();
        }
        public abstract string AddFlight();

        public  string UpdateFlight(int fightid)
        {
            if (!ValidateData())
            {
                return "Invalid Input";
            }
            try
            {
                if (DepartureID == ArrivalID) // for airport should be different
                {
                    return "Select different Airports";
                }
                else if (DepartureTime > ArrivalTime) // for flight timing
                {
                    return "Invalid Flight Timings";
                }
                else if ((ArrivalTime - DepartureTime).TotalDays > 2) // Optional
                {
                    return "Flight duration is too long.";
                }
                else
                {

                    bool flag = flightdl.UpdateFlight(fightid, Number, Seats, Price, Price_after_Tax, Discount, DepartureID, ArrivalID, TypeID, DepartureTime, ArrivalTime);
                    if (flag)
                    {
                        return "Flight Updated Successfully";
                    }
                    else
                    {
                        return "Try Again";
                    }
                }
            }
            catch (Exception ex)//db exception for duplicate flight
            {

                if (ex.Message == "Already Found")
                {
                    return ("This flight has already been added.");
                }
                else
                {
                    // For any other error
                    return ("An error occurred: " + ex.Message);
                }
            }
        }

        public bool ValidateData()
        {
            if (string.IsNullOrWhiteSpace(Number) ||  Number.StartsWith(" "))
            {
                return false;
            }
            if(Seats <= 0 || Price <= 0 || Discount < 0)
            {
                return false;
            }
           
            return true;
        }

    }
}
