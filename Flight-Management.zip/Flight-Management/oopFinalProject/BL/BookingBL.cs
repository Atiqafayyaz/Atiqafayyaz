﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using oopFinalProject.DL;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace oopFinalProject.BL
{
       
     public  class BookingBL
    {
        public int FlightID { get; private set; }
        public string Name { get; private set; }
        public string CNIC { get; private set; }
        public int UserID { get; private set; }

        public BookingDL bookingdl = new BookingDL();

        public BookingBL(int userid)
        {
            this.UserID = userid;
        }

        public BookingBL(int flight_id ,string name ,string cnic,int userid)
        {
            FlightID = flight_id;
            Name = name;
            CNIC = cnic;
            UserID = userid;
            
        }

        public string Bookflight()
        {
            if(!ValidateData())
            {
                return "Invalid Input";
            }
            try
            {
                bool flag = bookingdl.Bookflight(FlightID, Name, CNIC,UserID);
                if (flag)
                {
                    return "Your Flight Booked Successfully";
                }
                else
                {
                    return "please try again";
                }
            }
            catch (Exception ex)
            {

                if (ex.Message == "Already Booked")
                {
                    return ("Already Booked");
                }
                else
                {
                    // For any other error
                    return ("An error occurred: " + ex.Message);
                }
            }

        }
        public string GetNotified()
        {
            int count = bookingdl.GetNotified(UserID);
            if (count > 0)
            {
                bookingdl.DeleteCancelFlight(UserID);
                return "We regret to inform you that your reserved flight has been cancelled due to unforeseen operational reasons.";
            }
            else
            {
                return "There are currently no notifications regarding your flights.";
            }

        }

        private bool ValidateData()
        {
            if (string.IsNullOrWhiteSpace(Name) || !Regex.IsMatch(Name, @"^[a-zA-Z\s]+$") || Name.StartsWith(" "))
            {
                return false;
            }
            if (string.IsNullOrWhiteSpace(CNIC) || !Regex.IsMatch(CNIC, @"^\d+$") || CNIC.StartsWith(" "))
            {
                return false;
            }
            if (FlightID <=  0)
            {
                return false;
            }
            return true;
        }
    }
}
