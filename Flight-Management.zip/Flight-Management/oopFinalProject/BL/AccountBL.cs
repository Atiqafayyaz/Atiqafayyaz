﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using oopFinalProject.DL;

namespace oopFinalProject
{

     public class AccountBL
    {
        public AccountDL accountdl = new AccountDL();
        public string Username { get; private set; }
        public string Email { get; private set; }
        public string Password { get; private set; }

        public AccountBL(string username , string email , string password)
        {
            Username = username;
            Email = email;
            Password = password;
           

        }
        public AccountBL(string email , string password)
        {
            Email = email;
            Password = password;

        }
        public string AddAccount()
        {
            if (!ValidateData())
            {
                return "Invalid input please try again";

            }

            string Hashpassword = Hashedpassword.Hashpassword(Password);
            try
            {
                bool flag = accountdl.AddAccount(Username, Email, Hashpassword);
                if (flag)
                {
                    return "Acount Created Successfully";
                }
                else
                {
                    return "please try again";
                }
            }
            catch (Exception ex)//for duplicate email
            {
               
                if (ex.Message == "Use Different Email")
                {
                    return("Please use a different email.");
                }
                else
                {
                    // For any other error
                    return("An error occurred: " + ex.Message);
                }
            }
        }
        public int  Signin()
        {
            if(!ValidateSigninData())
            {
                return 0;
            }

            int EmailCheck = accountdl.GetEmailCount(Email); //if email not match
            if (EmailCheck == 0)
            {
                return 0;
            }
            string presentHashedPassword = accountdl.getUserHashPassword(Email);
            bool isPasswordCorrect = Hashedpassword.VerifyPassword(Password, presentHashedPassword);

            if (isPasswordCorrect)
            {

                int id = accountdl.getuserid(Email);
                return id;
            }

            else
            {
                return 0;
            }
        }
        public string Resetpassword()
        {
            if (!ValidateForgotpassword())
            {
                return "Invalid input please try again";

            }
            string Hashpassword = Hashedpassword.Hashpassword(Password);
            bool flag = accountdl.ResetPassword(Username, Hashpassword);
            if (flag)
            {
                return "Password Reset Successfully";
            }
            else
            {
                return "please try again";
            }

        }

        private bool ValidateSigninData()
        {

            if (string.IsNullOrWhiteSpace(Email) || !Email.Contains("@") || Email.StartsWith(" "))
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(Password) || Password.StartsWith(" "))
            {
                return false;
            }


            return true;
        }

        private bool ValidateForgotpassword()
        {
            if (string.IsNullOrWhiteSpace(Username) || !Regex.IsMatch(Username, @"^[a-zA-Z\s]+$") || Username.StartsWith(" "))
            {
                return false;
            }
            if (string.IsNullOrWhiteSpace(Password) || Password.StartsWith(" "))
            {
                return false;
            }


            return true;
        }
        private bool ValidateData()
        {
            if (string.IsNullOrWhiteSpace(Username) || !Regex.IsMatch(Username, @"^[a-zA-Z\s]+$") || Username.StartsWith(" "))
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(Email) || !Email.Contains("@") || Email.StartsWith(" "))
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(Password) || Password.StartsWith(" "))
            {
                return false;
            }


            return true;
        }
    }
}
