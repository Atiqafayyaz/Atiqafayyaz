﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using oopFinalProject.DL;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace oopFinalProject.BL
{
     public class staffBL
    {
        public staffDL staffdl;
        public string Name { get; private set; }
        public string Contact {  get; private set; }
        public string Address { get; private set; }
        public int DesignationID { get; private set; }
        public int AirportID { get; private set; }
        public string Date {  get; private set; }

        public staffBL(string name , string contact , string address , int designation , int airport , string date)
        {
            Name = name;
            Contact = contact;
            Address = address;
            DesignationID = designation;
            AirportID = airport;
            Date = date;
            staffdl = new staffDL();

        }

        public string AddStaff()
        {
            if (!ValidateData())
            {
                return "Invalid input please try again";

            }
            try
            {
                bool flag = staffdl.AddStaff(Name, Contact, Address, DesignationID, AirportID, Date);
                if (flag)
                {
                    return "Staff Added Successfully";
                }
                else
                {
                    return "please try again";
                }
            }
            catch (Exception ex)
            {

                if (ex.Message == "Already Found")
                {
                    return ("This Staff has already been added.");
                }
                else
                {
                    // For any other error
                    return ("An error occurred: " + ex.Message);
                }
            }
        }
        public string UpdateStaff(int staffid)
        {
            if (!ValidateData())
            {
                return "Invalid input please try again";

            }
            try
            {
                bool flag = staffdl.UpdateStaff(staffid, Name, Contact, Address, DesignationID, AirportID, Date);
                if (flag)
                {
                    return "Staff Updated Successfully";
                }
                else
                {
                    return "please try again";
                }
            }
            catch (Exception ex)
            {

                if (ex.Message == "Already Found")
                {
                    return ("This Staff has already been added.");
                }
                else
                {
                    // For any other error
                    return ("An error occurred: " + ex.Message);
                }
            }
        }

        private bool ValidateData()
        {
            if (string.IsNullOrWhiteSpace(Name) || !Regex.IsMatch(Name, @"^[a-zA-Z\s]+$") || Name.StartsWith(" "))
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(Contact) || Regex.IsMatch(Contact, @"^[a-zA-Z\s]+$") || Contact.StartsWith(" "))
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(Address) || !Regex.IsMatch(Address, @"^[a-zA-Z\s]+$") || Address.StartsWith(" "))
            {
                return false;
            }
           

            return true;
        }
    }
}

