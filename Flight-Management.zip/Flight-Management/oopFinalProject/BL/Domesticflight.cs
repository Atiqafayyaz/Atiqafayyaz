﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace oopFinalProject.BL
{
    public class Domesticflight : FlightBL
    {
        public string CNICRequired {  get; private set; } 
        public Domesticflight(string number, int seats, float price, float discount, int departureID, int arrivalID, int typeID, DateTime departureTime, DateTime arrivalTime ) : base(number, seats, price, discount, departureID, arrivalID, typeID, departureTime, arrivalTime )
        { 
            CNICRequired = "Yes";
        }

        public override double CalculateTax()
        {
            return Price * 0.10;

        }

        public override string AddFlight()
        {
            if (!ValidateData())
            {
                return "Invalid Input";
            }
            try
            {
                if (DepartureID == ArrivalID) // for airport should be different
                {
                    return "Select different Airports";
                }
                else if (DepartureTime > ArrivalTime) // for flight timing
                {
                    return "Invalid Flight Timings";
                }
                else if ((ArrivalTime - DepartureTime).TotalDays > 2) // Optional
                {
                    return "Flight duration is too long.";
                }
                else
                {
                    bool flag = flightdl.AddDomesticFlight(CNICRequired, Number, Seats, Price, Price_after_Tax, Discount, DepartureID, ArrivalID, TypeID, DepartureTime, ArrivalTime);
                    if (flag)
                    {
                        return "Flight Added Successfully";
                    }
                    else
                    {
                        return "Try Again";
                    }
                }
            }
            catch (Exception ex)//db exception for duplicate flight
            {

                if (ex.Message == "Already Found")
                {
                    return ("This flight has already been added.");
                }
                else
                {
                    // For any other error
                    return ("An error occurred: " + ex.Message);
                }
            }
        }
       

    }


}
            
       
